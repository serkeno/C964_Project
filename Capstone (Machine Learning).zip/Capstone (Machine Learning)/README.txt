Author: Alexander Brown
Version: 1.0
Date Updated: 11-2-2023
GitHub Source: https://github.com/serkeno/C964_Project
Email: abr1907@wgu.edu

Sources:

Nolan, R. (n.d.). One Hot Encoder with Python Machine Learning (Scikit-Learn) [Video]. YouTube. Retrieved October 28, 2023 from URL:
https://www.youtube.com/watch?v=rsyrZnZ8J2o

Smith B. (n.d.). Playlists[Bevan Smith 2]. Youtube. Retrieved October 26, 2023 from
https://www.youtube.com/watch?v=S7_xqXdh7UE&list=PLuVnJWOCzbxVfAVMU6bIFJ2jyzhEAnOCZ&pp=iAQB



